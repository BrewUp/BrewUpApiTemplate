﻿namespace $safeprojectname$.Models;

public class HelloRequest
{
    public string Name { get; set; } = string.Empty;
}